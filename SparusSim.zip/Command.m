function [Out] = Command(PosE,VitB,AccB)



% commande nulle

Thrust=[0 0 0];

Out=Thrust;
