%% here you can implement the code in order to have some figures ...
%%

figure(1)
hold on
grid on




